-- mengubah alamat mahasiswa

UPDATE mahasiswa
SET alamat = 'Jl. Raya No.5'
WHERE nim = '123456';
